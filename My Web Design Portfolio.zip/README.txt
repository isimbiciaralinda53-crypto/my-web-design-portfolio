ISIMBI LINDA - HTML & CSS PORTFOLIO

Files:
- index.html: portfolio content
- style.css: design and responsive layout

Preview:
Double-click index.html to open it in your browser.

Before publishing:
1. Check every sentence and make sure it is accurate for you.
2. The three project cards are clearly described as practice concepts, not client work.
3. Replace the contact note with a public contact method only if you want one.
4. Upload index.html and style.css to a GitHub repository and enable GitHub Pages to get a public website URL.
5. Only share the URL with Fiverr if it accepts this kind of portfolio link and the link is live.
